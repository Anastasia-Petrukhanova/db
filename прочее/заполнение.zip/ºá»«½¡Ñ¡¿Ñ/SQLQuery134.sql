insert into [Book] ([id], [id_client], [id_room], [start], [end]) values
(1, 1, 1, '2021-10-12', '2021-12-21')